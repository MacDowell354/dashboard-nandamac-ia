import os
from datetime import datetime
from flask import Flask, render_template, jsonify, request
from dotenv import load_dotenv
import pandas as pd

from utils import (
    load_dataframe, group_count, group_sum, group_avg,
    format_ptbr_int, format_ptbr_money, carregar_dados_origem_conversao
)

load_dotenv()
app = Flask(__name__)

_DATA_CACHE = { "df": pd.DataFrame(), "loaded_at": None }
CACHE_TTL_SECONDS = 300

def get_data():
    now = datetime.utcnow()
    needs_reload = (
        _DATA_CACHE["loaded_at"] is None or
        (now - _DATA_CACHE["loaded_at"]).total_seconds() > CACHE_TTL_SECONDS
    )
    if needs_reload:
        _DATA_CACHE["df"] = load_dataframe()
        _DATA_CACHE["loaded_at"] = now
        print(f"[INFO] Dados carregados às {_DATA_CACHE['loaded_at']} (UTC). Linhas: {_DATA_CACHE['df'].shape[0]}")
    return _DATA_CACHE["df"]

@app.context_processor
def inject_globals():
    current_path = request.path
    return dict(current_path=current_path, format_ptbr_int=format_ptbr_int, format_ptbr_money=format_ptbr_money)

@app.route("/")
def index():
    df = get_data()
    total_regs = len(df)
    colunas = list(df.columns)
    return render_template("index.html", total_regs=total_regs, colunas=colunas)

@app.route("/visao-geral")
def visao_geral():
    df = get_data()
    total_linhas = len(df)
    total_vendas = df["vendas"].sum() if "vendas" in df.columns else None
    total_valor = df["valor"].sum() if "valor" in df.columns else None
    por_estado = group_count(df, ["estado"]).sort_values("total", ascending=False).head(10)
    ticket_prof = group_avg(df, ["profissao"], "valor").sort_values("media", ascending=False).head(10)
    return render_template(
        "visao_geral.html",
        total_linhas=total_linhas,
        total_vendas=total_vendas,
        total_valor=total_valor,
        por_estado=por_estado.to_dict(orient="records"),
        ticket_prof=ticket_prof.to_dict(orient="records"),
    )

@app.route("/analise-regional")
def analise_regional():
    df = get_data()
    por_regiao = group_count(df, ["regiao"])
    por_estado = group_count(df, ["estado"])
    return render_template(
        "analise_regional.html",
        por_regiao=por_regiao.to_dict(orient="records"),
        por_estado=por_estado.to_dict(orient="records"),
    )

@app.route("/profissao-canal")
def profissao_canal():
    df = get_data()
    prof_regiao = group_count(df, ["profissao", "regiao"]).sort_values("total", ascending=False).head(50)
    prof_estado = group_count(df, ["profissao", "estado"]).sort_values("total", ascending=False).head(50)
    por_canal = carregar_dados_origem_conversao(df)
    return render_template(
        "profissao_canal.html",
        prof_regiao=prof_regiao.to_dict(orient="records"),
        prof_estado=prof_estado.to_dict(orient="records"),
        por_canal=por_canal.to_dict(orient="records"),
    )

@app.route("/projecao-resultados")
def projecao_resultados():
    df = get_data()
    serie = []
    if "data" in df.columns:
        tmp = df.dropna(subset=["data"])
        if not tmp.empty:
            ms = (tmp
                  .assign(mes=tmp["data"].dt.to_period("M").dt.start_time)
                  .groupby("mes")["valor"].sum()
                  .reset_index()
                  .rename(columns={"valor": "total"}))
            serie = ms.to_dict(orient="records")
    return render_template("projecao_resultados.html", serie=serie)

@app.route("/insights-ia")
def insights_ia():
    df = get_data()
    insights = []
    if "profissao" in df.columns and "valor" in df.columns:
        top = (df.groupby("profissao")["valor"].mean().sort_values(ascending=False).head(5))
        for prof, media in top.items():
            insights.append(f"Profissão '{prof}' apresenta ticket médio acima da média ({format_ptbr_money(media)}).")
    if "estado" in df.columns:
        cont = df["estado"].value_counts().head(5)
        for uf, n in cont.items():
            insights.append(f"Concentração relevante de registros no estado {uf} ({format_ptbr_int(n)}).")
    if not insights:
        insights = ["Envie/defina a planilha para habilitar insights mais robustos."]
    return render_template("insights_ia.html", insights=insights)

@app.route("/api/por-estado")
def api_por_estado():
    df = get_data()
    tab = group_count(df, ["estado"]).sort_values("total", ascending=False).head(15)
    return jsonify(tab.to_dict(orient="records"))

if __name__ == "__main__":
    debug = os.getenv("FLASK_DEBUG", "0") == "1"
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=debug)
